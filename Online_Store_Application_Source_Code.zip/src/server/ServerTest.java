//ServerTest has main() on server side

package server;

import java.rmi.RemoteException;
import java.rmi.server.UnicastRemoteObject;
import java.net.MalformedURLException;
import java.rmi.Naming;

import common.Inventory;
import common.StoreInterface;
import common.StoreImpl;

public class ServerTest extends UnicastRemoteObject {

	// default constructor
	protected ServerTest() throws RemoteException {
		super(); // invoke super class
	}

	public static void main(String[] args) throws RemoteException, MalformedURLException {

		try {

			// configure command line arguments
			String host = args[0];
			String port = args[1];
			
			// connect to inventory data
			Inventory.inventoryData();

			// create an object of type StoreImpl class
			StoreInterface remoteObject = new StoreImpl();

			// bind the remote object by the name RemoteCustomer
			String remoteStore = "//" + host + ":" + port + "/src";
			Naming.rebind(remoteStore, remoteObject);

			// print out message after binding the name to rmiregistry
			System.out.println("RemoteCustomer Server is ready at " + "//" + host + ":" + port);

			System.out.println("Server is connected");

		} catch (Exception ex) {
			ex.printStackTrace();
		}
	}
}
