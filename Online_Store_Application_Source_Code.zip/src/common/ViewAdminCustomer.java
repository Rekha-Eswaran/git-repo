package common;

public class ViewAdminCustomer implements StoreCommand{
	//data member
	private Admin userAdmin;
	private String userRole;

	// parameterized constructor
	ViewAdminCustomer(Admin userAdmin, String userRole) {
		this.userAdmin = userAdmin;
		this.userRole = userRole;
	}
	// default constructor
	ViewAdminCustomer() {
	}

	@Override
	public void executeCommand() {
		userAdmin.viewAdminCust(userRole); 
	}
}
