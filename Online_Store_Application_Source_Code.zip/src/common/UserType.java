package common;

import java.io.Serializable;

public class UserType implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	// data members
	private String type, name, adminCustName;

	// parameterized constructor
	public UserType(String type, String adminCustName) {
		this.type = type;
		this.adminCustName = adminCustName;
	}

	public UserType(String type, String adminCustName, String name) {
		this.type = type;
		this.adminCustName = adminCustName;
		this.name = name;
	}
	public UserType(String type) {
		this.type = type;
	}

	// default constructor
	public UserType() {
	}

	// set methods
	public void setName(String name) {
		this.name = name;
	}

	public void setUserType(String type) {
		this.type = type;
	}

	public void setAdminCustName(String adminCustName) {
		this.adminCustName = adminCustName;
	}

	// get methods
	public String getName() {
		return name;
	}

	public String getUserType() {
		return type;
	}

	public String getAdminCustName() {
		return adminCustName;
	}

}
