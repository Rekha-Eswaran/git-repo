package common;

public class AddItemsCart implements StoreCommand { // ReserveRoom()

	// data members
	private Customer cust;
	private StoreSession ss;

	// parameterized constructor
	AddItemsCart(Customer cust, StoreSession ss) {
		this.cust = cust;
		this.ss = ss;
	}

	//default constructor
	AddItemsCart() {
	}

	@Override
	public void executeCommand() {
		cust.addItemsCart(ss);
	}
}
