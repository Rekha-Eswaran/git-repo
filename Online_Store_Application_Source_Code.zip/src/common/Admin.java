//interface have Admin operations

package common;

public interface Admin {

	//display menu
	public abstract int display(StoreSession ss);
	
	//add, remove, display users (admin/customer)
	public abstract void addAdminCust(String userType);

	public abstract void removeAdminCust(String userType);

	public abstract void viewAdminCust(String userType);

	//add, remove, search items
	public abstract void addItem(String proces);

	public abstract void removeItem();

	public abstract void searchItems();

}
