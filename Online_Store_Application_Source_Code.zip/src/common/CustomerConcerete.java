//implementation of customer interface abstract methods

package common;

import java.util.*; //import list (collections)
import java.util.Scanner;

import client.ClientTest;

public class CustomerConcerete implements Customer {

	// data member
	private ClientTest client;

	// default constructor
	public CustomerConcerete() {
		client = new ClientTest();
	}

	// display customer menu
	public int display(StoreSession ss) {
		System.out.println("\nEnter your choice : ");
		System.out.println("1. Items list");
		System.out.println("2. Add Items");
		System.out.println("3. Update Items");
		System.out.println("4. Remove Items");
		System.out.println("5. Shopping Cart items list");
		System.out.println("6. Payment");
		System.out.println("7. Exit");

		int choice = 0;
		Scanner scan = new Scanner(System.in);
		try {
			choice = scan.nextInt();
		} catch (Exception e) {
			System.out.println(e);
		}
		return choice;
	}

	// view items list
	public void viewItmes(String item) {
		try {
			System.out.println("List of items: \n-----------------");
			List<String> items = new ArrayList<String>();
			items = client.searchItems();
					// searchItems = StoreInterface method
			int num = 1;
			// for each loop to iterate List<String> items
			for (String val : items) {
				System.out.println(num + ". " + val);
				num++;
			}
			System.out.println("\n");
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	// display items list
	public void searchItems() {
		try {
			List<String> items = new ArrayList<String>();
			items = client.searchItems();
			int num = 1;
			for (String val : items) {
				System.out.println(num + ". " + val);
				num++;
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	// add items in shopping cart
	public void addItemsCart(StoreSession ss) {
		try {
			//create object of type Registration
			Registration reg = new Registration();
			reg.addItemToCart(); 
			client.addItemsCart(reg.getItemNumber(), ss.getAdminCust().getAdminCustName(), 
					reg.getPhone(), reg.getCardNo());
			// System.out.println("##Items added in cart successfully!!!");
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	public void updateItemsCart(StoreSession ss) {
		try {
			//create array
			List<String> items = new ArrayList<String>();
			items = client.displayItems(ss.getAdminCust().getUserType(), ss.getAdminCust().getAdminCustName());
			if (items.size() > 0) {
				System.out.println("\nShopping Cart: ");
				int num = 1;
				for (String val : items) {
					System.out.println(num + ". " + val);
					num++;
				}
				// create object of type Registration
				Registration reg = new Registration();
				// call method to update item in cart and get item no
				reg.updateItem();
				client.updateItemIn(reg.getItemNumber(), ss.getAdminCust().getAdminCustName());
			} else {
				System.out.println("No items available");
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}	
	public void removeItemsCart(StoreSession ss) {
		try {
			//create array
			List<String> items = new ArrayList<String>();
			// create object of type Registration
			Registration reg = new Registration();
			
			items = client.displayItems(ss.getAdminCust().getUserType(), ss.getAdminCust().getAdminCustName());
			if (items.size() > 0) {
				System.out.println("\nItems list: ");
				int num = 1;
				for (String val : items) {
					System.out.println(num + ". " + val);
					num++;
				}			
				// call method to remove item in cart and get item no
				reg.RemoveItemsFromCart();
				client.removeItemIn(reg.getItemNumber());
			} else {
				System.out.println("##Items can not remove");
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}
