//implement of StoreCommand interface abstract method

package common;

public class UpdateItemsCart implements StoreCommand { 

	//data member
	private Customer cust;
	private StoreSession ss;

	// parameterized constructor
	UpdateItemsCart(Customer cust, StoreSession ss) {
		this.cust = cust;
		this.ss = ss;
	}

	// default constructor
	UpdateItemsCart() {
	}

	@Override
	public void executeCommand() {
		cust.updateItemsCart(ss);
	}
}
