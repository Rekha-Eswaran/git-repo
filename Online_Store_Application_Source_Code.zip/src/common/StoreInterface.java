package common;

import java.rmi.RemoteException;
import java.rmi.Remote;
import java.util.*;

public interface StoreInterface extends Remote {

	// add admin and login admin
	public abstract boolean addAdmin(String name, String email, String pass) throws RemoteException;

	public abstract boolean loginAdmin(String name, String pass) throws RemoteException;

	// view list of admin/customer registered
	public abstract List<String> viewAdminCustomer(String custType) throws RemoteException;

	// remove admin/customer from list
	public abstract boolean removeAdminCustomer(String type, String emailId) throws RemoteException;

	// add customer and login customer
	public abstract boolean addCustomer(String name, String email, String pass) throws RemoteException;

	public abstract boolean loginCustomer(String name, String pass) throws RemoteException;

	public abstract StoreSession ssLogin(String custType, String name) throws RemoteException;

	// view items, add items, remove items
	public abstract List<String> searchItems() throws RemoteException;

	public abstract boolean addItem(String proces, String itemNo, String itemName, String itemType, String price,
			String availStock) throws RemoteException;

	public abstract boolean removeItem(String itemNo) throws RemoteException;

	public abstract List<String> displayItems(String role, String email) throws RemoteException;

	public abstract List<String> updateItemIn(String itemNo, String email) throws RemoteException;

	// remove iems from customer shopping cart
	public abstract boolean removeItemIn(String itemNo) throws RemoteException;

	public abstract boolean addItemsCart(String itemNo, String email, String phone, String cardNo)
			throws RemoteException;
	
	public abstract boolean displayCart(String itemNo, String email, String phone, String cardNo)
			throws RemoteException;

}
