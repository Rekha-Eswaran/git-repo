//class to store items

package common;

import java.rmi.RemoteException;
import java.rmi.server.UnicastRemoteObject;

public class BrowseItems extends UnicastRemoteObject {

	//private static final long serialVersionUID = 1L;
	// data members
	private int price;
	private String itemNo, email, phone, cardNo, address;

	// parameterized constructor
	public BrowseItems(String itemNo, String email, String phone, String cardNo, int price) throws RemoteException {
		this.itemNo = itemNo;
		this.email = email;
		this.cardNo = cardNo;
		this.phone = phone;
		this.price = price;
	}
	public BrowseItems(String email, String phone, String cardNo) throws RemoteException {
		this.email = email;
		this.cardNo = cardNo;
		this.phone = phone;
	}

	// default constructor
	public BrowseItems() throws RemoteException {
		super();
	}

	// set methods
	public void setPhone(String phone) {
		this.phone = phone;
	}

	public void setItemNo(String itemNo) {
		this.itemNo = itemNo;
	}

	public void setPrice(int price) {
		this.price = price;
	}

	public void setCardNo(String cardNo) {
		this.cardNo = cardNo;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	// get methods
	public String getPhone() {
		return this.phone;
	}

	public String getItemNo() {
		return this.itemNo;
	}
	public int getPrice() {
		return this.price;
	}

	public String getEmail() {
		return this.email;
	}

	public String getCardNo() {
		return this.cardNo;
	}

	public String getAddress() {
		return this.address;
	}
}
