//class to implement Store command abstract method

package common;

public class RemoveItemsCart implements StoreCommand {
	// data members
	private StoreSession s;
	private Customer c;

	// parameterized constructor
	RemoveItemsCart(Customer c, StoreSession s) {
		this.c = c;
		this.s = s;
	}
	// default constructor
	RemoveItemsCart() {
	}

	@Override
	public void executeCommand() {
		c.removeItemsCart(s);
	}
}
