//implementation of storeInface abstract methods

package common;

import java.rmi.RemoteException;
import java.rmi.server.UnicastRemoteObject;
import java.util.*;

public class StoreImpl extends UnicastRemoteObject implements StoreInterface {

	// default constructor
	public StoreImpl() throws RemoteException {
		super(); // call superclass constructor
	}
	// admin view other admins and customer registry
	public List<String> viewAdminCustomer(String type) throws RemoteException {
		// create array list
		List<String> custs = new ArrayList<String>();
		String ut, n, em;
		try {
			// "for each" loop to iterate inventory items
			for (StoreUser val : Inventory.custs) {
				ut = val.getUserType();
				n = val.getUserName();
				em = val.getEmail();
				if (ut.equals(type))
					custs.add("Admin name : " + n + "\n     Email : " + em);
			}
		} catch (Exception e) {
			e.printStackTrace();
			System.out.println("Error to view admin name and email");
		}
		return custs;
	}
	// add new admin
	public boolean addAdmin(String name, String email, String pass) throws RemoteException {
		try {

			StoreUser adm = null;
			String em;
			// "for each" loop to iterate List of inventory
			for (StoreUser val : Inventory.custs) {
				em = val.getEmail();
				if (em.equals(email)) {
					adm = val;
				}
			} // end of "for" loop
			if (adm != null) {
				return false;
			} // else {
				// return true;
				// }
				// create object of type StoreUser
			StoreUser s = new StoreUser(name, email, pass, "Admin" );
			Inventory.custs.add(s); // add admin details in array list
			return true;

		} catch (Exception e) {
			System.out.println("Error to add new admin");
		}
		return false;
	}
	
	// login admin
	public boolean loginAdmin(String mail, String pass) throws RemoteException {
		try {
			String em, pa, ut;
			for (StoreUser val : Inventory.custs) {
				em = val.getEmail();
				pa = val.getPassword();
				ut = val.getUserType();
				if (em.equals(mail) && pa.equals(pass) && ut.equals("Admin")) {
					return true;
				} 
			}
		} catch (Exception e) {
			e.printStackTrace();
			System.out.println("Error in login admin");
		}
		return false;
	}
	// add new customer
	public boolean addCustomer(String name, String email, String pass) throws RemoteException {
		try {
			// "for each" loop to iterate inventory data
			StoreUser cust = null;
			String em;
			for (StoreUser val : Inventory.custs) {
				em = val.getEmail();
				if (em.equals(email)) {
					cust = val;
				}
			}
			if (cust != null) {
				return false;
			} // else {
				// return true;
				// }
				// create object of type StoreUser
			StoreUser s = new StoreUser(name, email, pass,"Customer");
			Inventory.custs.add(s); // add customer details in array list
			return true;
		} catch (Exception e) {
			e.printStackTrace();
			System.out.println("Error to add new customer");
		}
		return false;
	}
	
	// login customer
	public boolean loginCustomer(String mail, String pass) throws RemoteException {
		try {
			String em, pa, ut;
			for (StoreUser val : Inventory.custs) {
				em = val.getEmail();
				pa = val.getPassword(); 
				ut = val.getUserType();
				if (em.equals(mail) && pa.equals(pass)
						&& ut.equals("Customer")) {
					return true;
				} // else {
					// return false;
					// }
			}
		} catch (Exception e) {
			e.printStackTrace();
			System.out.println("Error in login customer");
		}
		return false;
	}

	// check admin and customer
	public StoreSession ssLogin(String cust, String name) throws RemoteException {
		try {
			StoreSession ss = new StoreSession(cust, name);
			return ss;
		} catch (Exception e) {
			System.out.println("Error to check user role");
		}
		return null;
	}

	// view list of items
	public List<String> searchItems() throws RemoteException {
		//create array list
		List<String> items = new ArrayList<String>();
		try {
			String num, nam, ty, pr, st;
			for (Item item : Inventory.items) {
				num = item.getItemNo();
				nam = item.getItemName();
				ty = item.getItemType(); 
				pr = item.getprice();
				st = item.getAvailStock();
				items.add("\nItem Number: " + num + "   Item Name: " + nam + "    Type: "
						+ ty + "    Price: " + pr + "   Available Stock: " + st);
				System.out.println("\n");
			}
		} catch (Exception e) {
			e.printStackTrace();
			System.out.println("Error to view items list!!!");
		}
		return items;
	}
	// admin add new item
	public boolean addItem(String value, String itemNo, String itemName, String type, String price, String availStock)
			throws RemoteException {
		try {
			Item it = null;
			String num;
			// "for each" loop to iterate inventory items
			for (Item val : Inventory.items) {
				num = val.getItemNo();
				if (num.equals(itemNo))
					it = val;
			}
			if (value.equals("Add")) {
				if (it != null) {
					return false;
				}		
			} else {
				if (it == null) {
					return false;
				}	
				else {
					Inventory.items.remove(it);
				}
			}
			//create object
			Item item = new Item();
			item.setItemNo(itemNo);
			item.setItemName(itemName);
			item.setItemType(type);
			item.setprice(price);
			item.setAvailStock(availStock);
			// add new items in inventory
			Inventory.items.add(item);
			return true;
		} catch (Exception e) {
			e.printStackTrace();
		}
		return false;
	}
		
	// admin remove items from inventory
	public boolean removeItem(String itemNo) throws RemoteException {
		try {
			Item it = null;
			String num;
			// "for each" loop to iterate inventory items
			for (Item x : Inventory.items) {
				num = x.getItemNo();
				if (num.equals(itemNo)) {
					it = x;
				}			
			}
			if (it != null) {
				Inventory.items.remove(it);
				return true;
			}
		} catch (Exception e) {
			System.out.println("Error to remove item!!!");
		}
		return false;
	}
	// admin remove customer from registry
	public boolean removeAdminCustomer(String type, String email) throws RemoteException {
		try {
			StoreUser su = null;
			String e, u;
			// "for each" loop to iterate inventory items
			for (StoreUser val : Inventory.custs) {
				e = val.getEmail();
				u = val.getUserType();
				if (e.equals(email) && u.equals(type)) {
					su = val;
				}				
			}
			if (su != null) {
				Inventory.custs.remove(su);
				return true;
			} // else {
				// return false;
				// }
		} catch (Exception e) {
			System.out.println("Error to remove customer!!!");
		}
		return false;
	}	
	// customer add items in shopping cart
	public boolean addItemsCart(String itemNo, String email, String phone, String cardNo) throws RemoteException {
		try {
			int stock = 0; // check stock available
			String num, st;
			Item it = null;
			for (Item item : Inventory.items) {
				num = item.getItemNo();
				st = item.getAvailStock();
				if (num.equals(itemNo)) {
					stock = Integer.parseInt(st);
					if (stock < 0) {
						System.out.println("Stock not available");
					}
					it = item;
				} // else {
					// return false;
					// }
			}
			//System.out.println("Add items in shopping cart");
			return true;
		} catch (Exception e) {
			System.out.println("Error to remove item from cart!!!");
		}
		return false;
	}
	// display customer shopping cart and purchase details
	public boolean displayCart(String itemNo, String email, String phone, String cardNo) throws RemoteException {
		try {
			int price = 0, stock = 0;
			String num, st;
			for (Item item : Inventory.items) {
				num = item.getItemNo();
				st = item.getAvailStock();
				if (num.equals(itemNo)) {
					stock = Integer.parseInt(st);
					if (stock < 0) {
						System.out.println("Stock not available");
					}
				}
			}
			return true;
		} catch (Exception e) {
			e.printStackTrace();
		}
		return false;
	}
	// display items to customer in shopping cart
	public List<String> displayItems(String type, String email) throws RemoteException {
		//create array
		List<String> items = new ArrayList<String>();
		String em, num, name = "Customer";
		try {
			for (BrowseItems b : Inventory.browsings) {
				em = b.getEmail();
				num = b.getItemNo();
				if ((type.equals(name) || email.equals(em))) {
					items.add("Customer email: " + em + "   Item no: " + num);
				}
					
			}
		} catch (Exception e) {
			System.out.println("Error to display cart items!!!");
		}
		return items;
	}
	
	// update cart items
	public List<String> updateItemIn(String itemNo, String email) throws RemoteException {
		//create array
		List<String> items = new ArrayList<String>();
		String num, em, ph;
		int pr;
		try {
			for (BrowseItems b : Inventory.browsings) {
				num = b.getItemNo();
				em = b.getEmail();
				pr = b.getPrice(); 
				ph = b.getPhone();
				
				if (itemNo.equals(num) && email.equals(em)) {
					items.add("Customer email: " + em + "   Item no: " + num + "  Price: "
							+ pr + "  Phone: " + ph);
				}
			}//end of "for each" loop

		} catch (Exception e) {
			System.out.println("Error to update cart item!!!");
		}
		return items;
	}	
	
	// remove items from shopping cart
	public boolean removeItemIn(String itemNo) throws RemoteException {

		try {
			BrowseItems items = null;
			for (BrowseItems b : Inventory.browsings) {
				String num = b.getItemNo();
				if (itemNo.equals(num))
					items = b;
			}
			if (items != null) {
				Inventory.browsings.remove(itemNo);
				return true;
			}

		} catch (Exception e) {
			e.printStackTrace();
		}
		return false;
	}

}
