package common;

import java.io.Serializable;

public class StoreSession implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	// declare variable
	UserType type;

	// parameterized constructor
	public StoreSession(String type, String name) {
		this.type = new UserType(type, name);
	}

	public StoreSession(String type) {
		this.type = new UserType(type);
	}

	// default constructor
	public StoreSession() {
	}

	// get user (admin/customer) role
	public UserType getAdminCust() {

		return type;
	}
}