//class to implement StoreCommand abstract method

package common;

public class SearchItems implements StoreCommand {
	private Admin ad;

	// parameterized constructor
	public SearchItems(Admin ad) {
		this.ad = ad;
	}

	// default constructor
	public SearchItems() {
	}

	@Override
	public void executeCommand() {
		ad.searchItems();
	}
}
