//payment class for customer pay 

package common;

public class Payment {

	// data members
	String custName, email, cardNo, itemNo, itemName;
	double totalPrice, price;
	int qty;

	// parameterized constructor
	public Payment(String custName, String email, String cardNo, String itemNo, String itemName, int qty,
			double price) {
		this.custName = custName;
		this.email = email;
		this.cardNo = cardNo;
		this.itemNo = itemNo;
		this.itemName = itemName;
		this.price = price;
		this.qty = qty;
	}

	// default constructor
	public Payment() {
	}

	// set methods
	public void setCustName(String name) {
		this.custName = name;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public void setCardNo(String no) {
		this.cardNo = no;
	}

	public void setItemNo(String itemNo) {
		this.itemNo = itemNo;
	}

	public void setItemName(String itemName) {
		this.itemName = itemName;
	}

	public void setPrice(double price) {
		this.price = price;
	}

	public void setQty(int qty) {
		this.qty = qty;
	}

	// calculate total price
	public double calPrice() {
		return this.price * this.qty;
	}

	// get methods
	public String getCustName() {
		return this.custName;
	}

	public String getEmail() {
		return this.email;
	}

	public String getCardNo() {
		return this.cardNo;
	}

	public String getItemNo() {
		return this.itemNo;
	}

	public String getItemName() {
		return this.itemName;
	}

	public double setPrice() {
		return this.price;
	}

	public int getQty() {
		return this.qty;
	}

	public void disPay() {
		System.out.println(pay());
	}
	public String pay() {
		return "your shipping is ready! Thanks for shopping!!!";
	}

}
