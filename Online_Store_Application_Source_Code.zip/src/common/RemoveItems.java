//implement Store command interface abstract method to call removeItem()

package common;

public class RemoveItems implements StoreCommand {
	//data member
	private Admin ad;

	// parameterized constructor
	RemoveItems(Admin ad) {
		this.ad = ad;
	}

	// default constructor
	RemoveItems() {
	}

	//override store command interface abstract method
	@Override
	public void executeCommand() {
		ad.removeItem();
	}
}
