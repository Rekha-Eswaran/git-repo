//Register admin's and customer details, and item details

package common;

import java.util.Scanner; //scanner class to get user input

public class Registration {

	// data members
	private int choice, qty;
	private String name, email, pass, phone, address, itemNo, cardNo, itemName, type, price, avail, input;
	private double total;

	// get user input
	Scanner scan = new Scanner(System.in);

	// parameterized constructor
	public Registration(String name, String email, String pass) {
		this.name = name;
		this.email = email;
		this.pass = pass;
	}

	public Registration(String itemNo, String itemName, String type, String price) {
		this.itemNo = itemNo;
		this.itemName = itemName;
		this.type = type;
		this.price = price;
	}

	// default constructor
	public Registration() {
	}

	// display user choice to login/registration
	public String displayLogin() { // login()

		// display choice
		System.out.println("---------------------");
		System.out.println("Welcome Online Store");
		System.out.println("---------------------\n");

		// get user input
		System.out.println("******* Enter your choice: ");
		System.out.println("Admin : A");
		System.out.println("Customer: C");
		input = scan.next();

		// check user input as only "A"
		if (input.equalsIgnoreCase("A")) {
			System.out.println("****** Please enter your choice :");
			System.out.println("1 - login Admin ");
			System.out.println("2 - Add New Admin ");
			// get user input choice
			choice = scan.nextInt();
			if (choice == 1 || choice == 2) {
				if (choice == 1)
					return "Admin";
				else if (choice == 2)
					return "New Admin";
			} else {
				return "false";
			}

		} // end of if
			// check user input as only "C"
		else if (input.equalsIgnoreCase("C")) {
			System.out.println("****** Please enter your choice :");
			System.out.println("1 - login Customer ");
			System.out.println("2 - Add New Customer ");
			// get user input choice
			choice = scan.nextInt();
			if (choice == 1 || choice == 2) {
				if (choice == 1)
					return "Customer";
				else if (choice == 2)
					return "New Customer";
			} else {
				return "false";
			}

		} // end of else if
		else {
			return "false";
		}

		return "false";
	}

	// admin/customer login/registration

	// add new user (admin/customer) to the inventory
	public void registerNewUser() {
		System.out.println("Please enter your details to register : ");
		System.out.println("Enter your name: ");
		name = scan.nextLine();
		System.out.println("\nEnter your Email: ");
		email = scan.nextLine().toLowerCase();
		System.out.println("\nEnter your password: ");
		pass = scan.nextLine();

	}

	// login user (admin/customer)
	public void loginUser() {
		System.out.println("Please enter your credentials: ");
		System.out.println("Email : ");
		email = scan.nextLine().toLowerCase();
		System.out.println("\nPassword : ");
		pass = scan.nextLine();
	}

	// remove existing user (admin/customer) from inventory
	public void getUserToRemove() {
		try {
			System.out.println("Enter email id to remove from register : ");
			email = scan.nextLine().toLowerCase();
			System.out.println();
		} catch (Exception e) {
			System.out.println("\n*********User details are not deleted*********");
			e.printStackTrace();
		}
	}

	// items add, delete, update
	// get items details to add/update in the inventory
	public void getItemToAdd(String value) {
		try {
			String s = value;
			if (s == "Add") {
				System.out.println("Enter new item number: ");
				itemNo = scan.nextLine();
				System.out.println("Enter Item name: ");
				itemName = scan.nextLine();
				System.out.println("Enter Item type: ");
				type = scan.nextLine();
				System.out.println("Enter Item price: ");
				price = scan.nextLine();
				System.out.println("Enter quantity: ");
				avail = scan.nextLine();
				System.out.println("Item available in inventory now!!!");
			} else if (s != "Add") {
				System.out.println("Enter item number to update: ");
				itemNo = scan.nextLine();
				System.out.println("Enter Item name: ");
				itemName = scan.nextLine();
				System.out.println("Enter Item type: ");
				type = scan.nextLine();
				System.out.println("Enter Item price: ");
				price = scan.nextLine();
				System.out.println("Enter quantity: ");
				avail = scan.nextLine();
				System.out.println("Item available in inventory now!!!");
			}
		} catch (Exception e) {
			System.out.println("Items are not added successfully");
			e.printStackTrace();
		}
	}

	// get items details to remove from inventory
	public void getItemToRemove() {
		try {
			System.out.println("Enter the item number to remove from inventory: ");
			itemNo = scan.nextLine();
			System.out.println();
		} catch (Exception e) {
			System.out.println("\n*********Item details are not deleted*********");
			e.printStackTrace();
		}
	}

	// shopping cart add, update, remove
	// add items to shopping cart
	public void addItemToCart() {
		try {
			System.out.println("Enter Item number: ");
			itemNo = scan.nextLine();
			System.out.println("\nEnter Item name: ");
			itemName = scan.nextLine();
			System.out.println("\nEnter quantity: ");
			cardNo = scan.nextLine();
			if (Integer.parseInt(cardNo) > 10) {
				System.out.println("##Sorry! Quantity is more than avaiable stock");
			} else {
				System.out.println("##Items added in shopping cart successsfully");
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	// update items in shopping cart
	public void updateItem() {
		try {
			System.out.println("Enter the item number to update: ");
			itemNo = scan.nextLine();
		} catch (Exception e) {
			System.out.println("Item cannot be updated ");
			e.printStackTrace();
		}
	}

	// remove items from shopping cart
	public void RemoveItemsFromCart() {

		try {
			System.out.println("Enter the item number to remove: ");
			itemNo = scan.nextLine();
		} catch (Exception e) {
			System.out.println("Item cannot be removed from shopping cart ");
			e.printStackTrace();
		}
	}

	// set user (admin's/customer) name, email, phone, password, address
	public void setName(String name) {
		this.name = name;
	}

	public void setPhone(String phone) {
		this.phone = phone;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public void setPassword(String pass) {
		this.pass = pass;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	// get user name, email, phone, password, address
	public String getName() {
		return name;
	}

	public String getEmail() {
		return email;
	}

	public String getPhone() {
		return phone;
	}

	public String getPassword() {
		return pass;
	}

	public String getAddress() {
		return address;
	}

	// set item number, name, description, available stock, and quantity
	public void setItemNo(String itemNo) {
		this.itemNo = itemNo;
	}

	public void setItemName(String itemName) {
		this.itemName = itemName;
	}

	public void setDescription(String desc) {
		this.type = desc;
	}

	public void setPrice(String price) {
		this.price = price;
	}

	public void setAvailableStock(String avail) {
		this.avail = avail;
	}

	public void setCardNo(String cardNo) {
		this.cardNo = cardNo;
	}

	public void setQuantity(int qty) {
		this.qty = qty;
	}

	// get item number, name, description, available stock, and quantity
	public String getItemNumber() {
		return itemNo;
	}

	public String getItemName() {
		return itemName;
	}

	public String getDescription() {
		return type;
	}

	public String getPrice() {
		return price;
	}

	public String getAvailableStock() {
		return avail;
	}

	public String getCardNo() {
		return cardNo;
	}

	public int getQuantity() {
		return qty;
	}

	public double getTotalPRice() {
		return total;
	}
}
