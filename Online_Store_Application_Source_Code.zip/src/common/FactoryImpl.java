package common;


public class FactoryImpl {
	/*
	//default constructor
	public FactoryImpl(){}
	*/
	public static AbstractFactory getFact(String choice) {

		if (choice.equalsIgnoreCase("Admin")) {
			return new AdminFactoryImpl();
		} else if (choice.equalsIgnoreCase("Customer")) {
			return new CustomerFactoryImpl();
		}
		return null;
	}
}
