//methods for customer functions

package common;

public interface Customer {
	// display list of items
	public abstract void searchItems();

	// add items to cart
	public abstract void addItemsCart(StoreSession ss);

	public abstract int display(StoreSession ss);

	// update items in cart
	public abstract void updateItemsCart(StoreSession ss);

	//remove items from cart
	public abstract void removeItemsCart(StoreSession ss);

	public abstract void viewItmes(String item);
}
