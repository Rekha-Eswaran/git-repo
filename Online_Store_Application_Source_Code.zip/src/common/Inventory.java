package common;

import java.rmi.RemoteException;
import java.rmi.server.UnicastRemoteObject;
import java.util.*;

public class Inventory extends UnicastRemoteObject {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	//declare objects with generic
	public static List<BrowseItems> browsings = new ArrayList<BrowseItems>();
	public static List<StoreUser> custs = new ArrayList<StoreUser>();
	public static List<Item> items = new ArrayList<Item>();

	//default constructor
	public Inventory() throws RemoteException {
		super();        //invoke super class
	}

	public static void inventoryData() throws RemoteException {
		try {
			//add items 
			Item i1 = new Item("10", "Soup","Liquid", "2", "10"); //pass values with constructor
			items.add(i1);
			
			Item i2 = new Item("20","Rice", "Favourite", "8", "25");
			items.add(i2);
			
			Item i3 = new Item("30","Tomato", "Veges","3", "15");
			items.add(i3);
			
			BrowseItems b1 = new BrowseItems("10", "s@gmail.com", "12323145", "45673829", 40);
			browsings.add(b1);

			//add customer 
			StoreUser c1 = new StoreUser("Varshath","va@gmail.com", "va123", "Customer");
			custs.add(c1);
			
			StoreUser c2 = new StoreUser("Ruthvick","ru@gmail.com", "ru123", "Customer");
			custs.add(c2);
			
			StoreUser c3 = new StoreUser("Raj","raj@gmail.com", "r123","Customer");
			custs.add(c3);

			//add admins
			StoreUser a1 = new StoreUser("Rekha","re@gmail.com", "re123", "Admin" );
			//add admin value in array
			custs.add(a1);

			StoreUser a2 = new StoreUser("Rajesh", "ra@gmail.com", "ra123", "Admin");
			custs.add(a2);
			
			StoreUser a3 = new StoreUser("Dhishana","dh@gmail.com", "dh123", "Admin");
			custs.add(a3);

		} catch (Exception e) {
			System.out.println("Cannot add inventory data");
			e.printStackTrace();
		}
	}
}
