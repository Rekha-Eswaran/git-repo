//Abstract Factory interface for Admin and Customer classes
//These abstract methods are implemented in AdminFactoryImpl class

package common;

public interface AbstractFactory {
	
	//abstract method of type Admin
	public abstract Admin getAdmin(String ad);

	//abstract method of type Customer
	public abstract Customer getCustomer(String cust);
}
