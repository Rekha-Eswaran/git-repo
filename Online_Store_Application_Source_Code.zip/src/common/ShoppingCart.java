package common;

public class ShoppingCart {
	//default constructor
	public ShoppingCart(){
		System.out.println("Shopping Cart:");
		System.out.println("1.Item no: 10     "
				+ "Item name: Soup         "
				+"Price: 18                "
				+"Quantity: 6");
		System.out.println("1.Item no: 20     "
				+ "Item name: Rice         "
				+"Price: 40                "
				+"Quantity: 5");
		
	}
	
}
