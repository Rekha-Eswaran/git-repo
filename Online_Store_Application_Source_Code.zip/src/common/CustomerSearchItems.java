package common;

public class CustomerSearchItems implements StoreCommand {
	// data member
	private Customer cust;

	// parameterized constructor
	CustomerSearchItems(Customer cust) {
		this.cust = cust;
	}
	// default constructor
	CustomerSearchItems() {
	}

	@Override
	public void executeCommand() {
		cust.searchItems();
	}
}
