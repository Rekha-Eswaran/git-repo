//class to implement store command abstract methods to add new admin and customer

package common;

public class AddAdminCustomer implements StoreCommand {

	//data members
	private Admin userAdmin;
	private String userRole;

	// parameterized constructor
	AddAdminCustomer(Admin userAdmin, String userRole) { 
		this.userAdmin = userAdmin;
		this.userRole = userRole;
	}

	// default constructor
	AddAdminCustomer() {
	}

	@Override
	public void executeCommand() {
		userAdmin.addAdminCust(userRole);
	}

}
