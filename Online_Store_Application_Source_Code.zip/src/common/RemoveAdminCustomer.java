//implement store command interface abstract method to call removeAdminCust()

package common;

public class RemoveAdminCustomer implements StoreCommand {
	// data member
	private String userRole;
	private Admin userAdmin;

	// parameterized constructor
	RemoveAdminCustomer(Admin userAdmin, String userRole) {
		this.userAdmin = userAdmin;
		this.userRole = userRole;
	}

	// default constructor
	RemoveAdminCustomer() {
	}

	@Override
	public void executeCommand() {
		userAdmin.removeAdminCust(userRole);
	}
}
