package common;

import java.rmi.RemoteException;
import java.rmi.server.UnicastRemoteObject;

public class StoreUser extends UnicastRemoteObject {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	// data members
	private String name, email, pass, userType, address, phone;

	// parameterized constructor
	public StoreUser(String name, String address, String phone, String email, 
			String pass, String userType)throws RemoteException {
		this.name = name;
		this.address = address;
		this.phone = phone;
		this.email = email;
		this.pass = pass;
		this.userType = userType;
	}
	public StoreUser(String name, String email, String pass, String userType)throws RemoteException {
		this.name = name;
		this.email = email;
		this.pass = pass;
		this.userType = userType;
	}
	
	public StoreUser(String name, String email, String userType)throws RemoteException {
		this.name = name;
		this.email = email;
		this.userType = userType;
	}

	// default constructor
	public StoreUser() throws RemoteException {
		super();
	}

	// set methods
	public void setUserName(String name) {
		this.name = name;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public void setPassword(String pass) {
		this.pass = pass;
	}

	public void setUserType(String userType) {
		this.userType = userType;
	}

	public void setPhone(String phone) {
		this.phone = phone;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	// get methods
	public String getUserName() {
		return name;
	}

	public String getEmail() {
		return email;
	}

	public String getPassword() {
		return pass;
	}

	public String getUserType() {
		return userType;
	}

	public String getPhone() {
		return this.phone;
	}

	public String getAddress() {
		return this.address;
	}
}
