package common;

public class StoreDispatcher {

	private AbstractFactory adFact, custFact;

	// default constructor
	public StoreDispatcher() {
		adFact = FactoryImpl.getFact("Admin");
		custFact = FactoryImpl.getFact("Customer");
	}

	public void menu(String check, StoreSession ss) {
		// get user choice
		int choice = 0;

		if (check.equalsIgnoreCase("Admin")) {
			// create object to get user type
			Admin ad = adFact.getAdmin("Admin");
			// create object of type ListInvoker
			ListInvoker ln = new ListInvoker();
			while (true) {
				// display user choice and get user input
				choice = ad.display(ss);

				if (choice == 1) {
					// create reference of type ViewAdminCustomer
					StoreCommand sc = new ViewAdminCustomer(ad, "Admin");
					ln.setValue(sc);
					ln.getValue();

				} else if (choice == 2) {
					// create reference of type AddADminCustomer
					StoreCommand sc = new AddAdminCustomer(ad, "Admin");
					ln.setValue(sc);
					ln.getValue();

				} else if (choice == 3) {
					// create reference of type ViewAdminCustomer
					StoreCommand sc = new ViewAdminCustomer(ad, "Customer");
					ln.setValue(sc);
					ln.getValue();

				} else if (choice == 4) {
					// create reference of type AddAdminCustomer
					StoreCommand sc = new AddAdminCustomer(ad, "Customer");
					ln.setValue(sc);
					ln.getValue();

				} else if (choice == 5) {
					// create reference of type RemoveAdminCustomer
					StoreCommand sc = new RemoveAdminCustomer(ad, "Customer");
					ln.setValue(sc);
					ln.getValue();
				} else if (choice == 6) {
					// create reference of type SearchItems
					StoreCommand sc = new SearchItems(ad); // refer "SearchItems" class
					ln.setValue(sc);
					ln.getValue();
				} else if (choice == 7) {
					// create reference of type AddItems
					StoreCommand sc = new AddItems(ad, "Add");
					ln.setValue(sc);
					ln.getValue();
				} else if (choice == 8) {
					// create reference of type AddItems
					StoreCommand sc = new AddItems(ad, "Update");
					ln.setValue(sc);
					ln.getValue();
				} else if (choice == 9) {
					// create reference of type RemoveItems
					StoreCommand sc = new RemoveItems(ad);
					ln.setValue(sc);
					ln.getValue();
				} else if (choice == 10) {
					System.exit(0); // come out of loop
				} else {
					System.out.println("Invalid choice!!!");
				}
			}

		} else if (check.equalsIgnoreCase("Customer")) {

			// create object of type Payment
			Payment p = new Payment();
			// create customer object
			Customer cust = custFact.getCustomer("Customer");
			// create object of type ListInvoker
			ListInvoker ln = new ListInvoker();

			while (true) {
				// display user choice and get user input
				choice = cust.display(ss);
				// if else statements to do admin process
				if (choice == 1) {
					// create reference of type CustomerSearchItems
					StoreCommand sc = new CustomerSearchItems(cust);
					ln.setValue(sc);
					ln.getValue();
				} else if (choice == 2) {
					// create reference of type AddItemsCart
					StoreCommand sc = new AddItemsCart(cust, ss);
					ln.setValue(sc);
					ln.getValue();
				} else if (choice == 3) {
					// create reference of type UpdateItemsCart
					StoreCommand sc = new UpdateItemsCart(cust, ss);
					ln.setValue(sc);
					ln.getValue();
				} else if (choice == 4) {
					// create reference of type RemoveItemsCart
					StoreCommand sc = new RemoveItemsCart(cust, ss);
					ln.setValue(sc);
					ln.getValue();
				} else if (choice == 5) {
					// create object of type ShoppingCart
					ShoppingCart sc = new ShoppingCart();
				} else if (choice == 6) {
					// call method
					p.disPay();
				} else if (choice == 7) {
					System.exit(0); // come out of loop
				} else {
					System.out.println("Invalid choice!!!");
				}
			} // end of while()
		} // end of "else if"
	}// end of method
}
