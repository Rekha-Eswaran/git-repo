package common;

import java.rmi.RemoteException;
import java.rmi.server.UnicastRemoteObject;

public class Item extends UnicastRemoteObject {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	// data member
	private String itemNo, itemName, type, price, availStock;
	private double total;

	// parameterized constructor
	public Item(String itemNo, String itemName, String type, String price, String availStock) throws RemoteException {
		super();
		this.itemNo = itemNo;
		this.itemName = itemName;
		this.type = type;
		this.price = price;
		this.availStock = availStock;
	}

	public Item(String itemNo, String itemName, String availStock) throws RemoteException {
		this.itemNo = itemNo;
		this.itemName = itemName;
		this.availStock = availStock;
	}

	// default constructor
	protected Item() throws RemoteException {
		super();
	}

	// set methods
	public void setItemNo(String itemNo) {
		this.itemNo = itemNo;
	}

	public void setItemName(String itemName) {
		this.itemName = itemName;
	}

	public void setItemType(String type) {
		this.type = type;
	}

	public void setprice(String price) {
		this.price = price;
	}

	public void setAvailStock(String availStock) {
		this.availStock = availStock;
	}

	public void setTotal(double total) {
		this.total = total;
	}

	// get methods
	public String getItemNo() {
		return this.itemNo;
	}

	public String getItemName() {
		return this.itemName;
	}

	public String getItemType() {
		return this.type;
	}

	public String getprice() {
		return this.price;
	}

	public String getAvailStock() {
		return this.availStock;
	}

	public double getTotal() {
		return this.total;
	}
}
