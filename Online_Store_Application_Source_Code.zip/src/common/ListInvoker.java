//invoker class

package common;

import java.util.*;

public class ListInvoker {
	
	// create object of type ArrayList
	private List<StoreCommand> list = new ArrayList<StoreCommand>();
	private StoreCommand theCommand;

	// parameterized constructor
	public ListInvoker(StoreCommand theCommand) {
		super();
		this.theCommand = theCommand;
	}

	// default constructor
	public ListInvoker() {
	}

	// call command's execute method
	public void execute() {

		theCommand.executeCommand();
	}

	// method to add list
	public void setValue(StoreCommand sc) {
		list.add(sc);
	}

	// method to get list
	public void getValue() {
		for (StoreCommand sc : list) {
			sc.executeCommand();
		}
		list.clear();
	}
}
