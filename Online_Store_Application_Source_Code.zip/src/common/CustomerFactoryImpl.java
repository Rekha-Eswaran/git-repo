//implement AbstractFactory interface abstract methods

package common;

public class CustomerFactoryImpl implements AbstractFactory {
	// get admin method
	public Admin getAdmin(String ad) {
		return null;
	}
	// get customer method
	public Customer getCustomer(String cust) {
		if (cust == null)
			return null;

		if (cust.equalsIgnoreCase("Customer"))
			return new CustomerConcerete();
		return null;
	}
}
