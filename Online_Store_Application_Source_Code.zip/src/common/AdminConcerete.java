//class to implement Admin abstract methods

package common;

import java.util.*;
import java.util.Scanner;

import client.ClientTest;

public class AdminConcerete implements Admin {

	// data member
	private ClientTest ct;

	// default constructor
	public AdminConcerete() {
		ct = new ClientTest();
	}

	// display admin choice
	public int display(StoreSession ss) {
		System.out.println("\n*******Enter your choice : ");
		System.out.println("1. View Admin registry");
		System.out.println("2. Add new Admin");
		System.out.println("3. View Customer registry");
		System.out.println("4. Add New Customer");
		System.out.println("5. Remove Customer");
		System.out.println("6. View Items List");
		System.out.println("7. Add New Item");
		System.out.println("8. Update Item");
		System.out.println("9. Remove Item From Inventory");
		System.out.println("10. Exit");

		// scanner object to get user input
		Scanner scan = new Scanner(System.in);
		int choice = 0;
		try {
			choice = scan.nextInt();
		} catch (Exception e) {
			e.printStackTrace();
		}
		return choice;
	}

	// add admin and customer in the list
	public void addAdminCust(String type) {
		try {
			// create object of type Registration
			Registration reg = new Registration();
			// call register as new admin and customer
			reg.registerNewUser();

			// check for "admin" and customer" to register
			if (type == "Admin")
				ct.addAdmin(true, reg.getName(), reg.getEmail(), reg.getPassword()); // addAdmin = StoreInterface method
			else
				ct.addCustomer(true, reg.getName(), reg.getEmail(), reg.getPassword());
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	// view admin and customers list
	public void viewAdminCust(String userType) {
		try {
			// put number in output
			int num = 1;
			System.out.println(userType + " list: \n------------------");
			List<String> ut = new ArrayList<String>();
			ut = ct.viewAdminCustomer(userType);
					// viewAdminCustomer = StoreInterface method
			// for each loop to iterate list
			for (String val : ut) {
				System.out.println(num + ". " + val);
				num++;
			}
			System.out.println("\n");
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	// check user and remove customer
	public void storeUser(String email, String userType) {
		if (email != null) {
			ct.removeAdminCustomer(userType, email);
		}
		System.out.println("User type:  \n------------");
		System.out.println("Name: " + userType + " Email: " + email);
	}

	// remove admin and customers from list
	public void removeAdminCust(String userType) {
		try {
			// create object of type Registration
			Registration reg = new Registration();
			reg.getUserToRemove(); // call method to get user type
			ct.removeAdminCustomer(userType, reg.getEmail());
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	// add new items in inventory
	public void addItem(String proces) {
		try {
			// create object of type Registration
			Registration reg = new Registration();
			reg.getItemToAdd(proces);

			// add items details in controller
			ct.addItem(proces, reg.getItemNumber(), reg.getItemName(), reg.getDescription(), reg.getPrice(),
					reg.getAvailableStock());
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	// search items
	public void searchItems() {
		try {
			System.out.println("Items list:\n------------");
			List<String> items = new ArrayList<String>();
			items = ct.searchItems();
			int num = 1;
			// "for each" loop to iterate list of items
			for (String val : items) {
				System.out.println(num + ". " + val);
				num++;
			}
			System.out.println("\n");
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	// remove items from inventory
	public void removeItem() {
		try {
			// create object of type Registration
			Registration reg = new Registration();
			reg.getItemToRemove();
			ct.removeItem(reg.getItemNumber());
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

}// end of class
