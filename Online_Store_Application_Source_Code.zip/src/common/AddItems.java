//class to implement store command methods

package common;

public class AddItems implements StoreCommand {
	// data members
	private Admin userAdmin;
	private String value;

	// parameterized constructor
	AddItems(Admin userAdmin, String value) {
		this.userAdmin = userAdmin;
		this.value = value;
	}

	// parameterized constructor
	AddItems(Admin userAdmin) {
		this.userAdmin = userAdmin;
	}

	// default constructor
	AddItems() {
	}

	// override StoreCommand interface abstract method
	public void executeCommand() {
		userAdmin.addItem(value);
	}
}
