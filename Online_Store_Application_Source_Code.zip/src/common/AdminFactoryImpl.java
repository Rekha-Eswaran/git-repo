//AdminFactoryImpl implement abstract methods of AbstractFactory interface 

package common;

public class AdminFactoryImpl implements AbstractFactory {

	/*
	 * //default constructor public AdminFactoryImpl(){}
	 */
	// override getAdmin method
	public Admin getAdmin(String ad) {
		if (ad == null) {
			return null;
		}

		if (ad.equalsIgnoreCase("Admin")) {
			return new AdminConcerete();
		}

		return null;
	}

	// override getCustomer method and return null
	public Customer getCustomer(String cust) {
		return null;
	}
}
