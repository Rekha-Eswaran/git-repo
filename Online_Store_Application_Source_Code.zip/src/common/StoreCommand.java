//interface to execute admin and customer commands

package common;

public interface StoreCommand {
	public abstract void executeCommand();

}
