//Front controller to authorization admin and customer login or registration

package client;

import java.rmi.Remote;
import java.rmi.RemoteException;

import common.StoreSession;
import common.StoreDispatcher;
import common.Registration;

public class FrontController {

	// declare objects
	private ClientTest user = new ClientTest();
	private Registration reg = new Registration();

	// data members
	private StoreDispatcher sd;
	private StoreSession ss = null;

	// default constructor
	public FrontController() {

		sd = new StoreDispatcher();
	}

	// check user authentication while login and register process
	private boolean checkAuthenticity(String check) {

		// create variables
		String name, email, pass;

		if (check.equalsIgnoreCase("Admin")) { // check whether admin is logging in
			// call loginuser() to get user input
			reg.loginUser();

			// store user input password, email to check authentication
			email = reg.getEmail();
			pass = reg.getPassword();

			if (user.loginAdmin(email, pass)) {
				ss = user.ssLogin("Admin", email);
				System.out.println("\n###Congtrats!!! You logged in as " + ss.getAdminCust().getUserType());
				// get.UserType() = UserType class method to check type of user

				return true;
			}

		} else if (check.equalsIgnoreCase("Customer")) { // check whether customer is logging in

			// call loginuser() to get user input
			reg.loginUser();
			email = reg.getEmail();
			pass = reg.getPassword();

			if (user.loginCustomer(email, pass)) {
				ss = user.ssLogin("Customer", email);
				System.out.println("You logged in as " + ss.getAdminCust().getUserType());
				return true;
			}

		} else if (check.equalsIgnoreCase("New Admin")) { // check whether new admin added in
			// call registerNewUser() to get user input
			reg.registerNewUser();

			// to store user input name, email, password
			name = reg.getName();
			email = reg.getEmail();
			pass = reg.getPassword();

			user.addAdmin(false, name, email, pass);
			return true;

		} else if (check.equalsIgnoreCase("New Customer")) { // check whether new customer added in
			reg.registerNewUser();

			name = reg.getName();
			email = reg.getEmail();
			pass = reg.getPassword();

			user.addCustomer(false, name, email, pass);
			return true;
		}

		return false;
	}

	//check login
	public void viewLogin(String check) {
		if (checkAuthenticity(check))
			sd.menu(check, ss); // call "StoreDispatcher" to display operations
		else
			System.out.println("Invalid username/emailId!!!");
	}
}
