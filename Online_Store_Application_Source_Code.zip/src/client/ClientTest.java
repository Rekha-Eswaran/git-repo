//ClientTest has main() on client side

package client;

import java.rmi.Naming;
import java.rmi.RemoteException;
import java.util.*;
//import java.rmi.registry.LocateRegistry;
//import java.rmi.registry.Registry;

import common.Registration;
import common.StoreInterface;
import common.StoreSession;

public class ClientTest {

	// data members
	public static StoreInterface remoteClient;
	// StoreSession ss = null;

	public static void main(String[] args) throws RemoteException {
		// create object of type FrontController and Registration
		FrontController fc = new FrontController();
		Registration reg = new Registration();

		try {
			// configure command line arguments
			String host = args[0];
			String port = args[1];

			// bind the remote object by the name RemoteCustomer
			// String remoteCustomerName = "//" + host + ":" + port + "/RemoteUser";
			// StoreInterface customerStub = (StoreInterface)
			// Naming.lookup(remoteCustomerName);

			String remoteObj = "//" + host + ":" + port + "/src";
			// lookup method to find reference of remote object
			remoteClient = (StoreInterface) Naming.lookup(remoteObj);

			System.out.println("Connected to Server");
			System.out.println("Found server object at " + "//" + host + ":" + port);

			// display menu to admin and customer
			fc.viewLogin(reg.displayLogin());

		} catch (Exception e) {
			e.printStackTrace();
			System.out.println("\nCan't connect to server");
		}
	}

	// method to check whether "customer" or "admin" role
	public StoreSession ssLogin(String custType, String name) {
		// create object
		StoreSession ss = null;
		// StoreSession st = null;
		try {
			ss = remoteClient.ssLogin(custType, name);
			// st = remoteClient.ssLogin(custType);
			// declare variable
			int var = 0;
			if (var == 0) {
				// System.out.println("calling store session method"); //debug statement
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return ss;
	}

	// method for admin to add other admin
	public void addAdmin(Boolean flag, String name, String email, String pass) {
		try {
			// System.out.println("###New Admin added successfully\n");
			if (remoteClient.addAdmin(name, email, pass)) {
				System.out.println("###New Admin added successfully\n");
				if (!flag) {
					// create object of type FrontController and Registration
					FrontController fc = new FrontController();
					Registration reg = new Registration();

					// call display method and get user input choice
					fc.viewLogin(reg.displayLogin());
				}
			} else {
				System.out.println("\n###Pease enter new email and password");
			}
		} catch (Exception e) {
			e.printStackTrace();
			System.out.println("\nCan't add new admin");
		}
	}

	// method for admin to login
	public boolean loginAdmin(String name, String pass) {
		// System.out.println("\n Calling login admin method from clientTest");
		boolean b = true;

		try {
			b = remoteClient.loginAdmin(name, pass);
		} catch (Exception e) {
			System.out.println("\nCan't login admin");
			e.printStackTrace();
		}
		return b;
	}

	// method for admin to remove customers
	public void removeAdminCustomer(String type, String email) {
		// System.out.println("\n Calling remove customer method from clientTest");
		try {
			if (remoteClient.removeAdminCustomer(type, email)) {
				System.out.println(type + " deleted from register");
			} else {

				System.out.println(type + " not able to find in register");
			}
		} catch (Exception e) {
			e.printStackTrace();
			// System.out.println("\nCan't remove customer from registery");
		}
	}

	// method for customer to login
	public boolean loginCustomer(String name, String pass) {
		boolean b = false;
		// System.out.println("\n Calling login customer method from clientTest");
		try {
			b = remoteClient.loginCustomer(name, pass);
		} catch (Exception e) {
			e.printStackTrace();
			// System.out.println("\nCan't login customer");
		}

		return b;
	}

	// method for admin to view list of admins and customers
	public List<String> viewAdminCustomer(String type) {
		List<String> role = new ArrayList<String>();
		try {
			role = remoteClient.viewAdminCustomer(type);
		} catch (Exception e) {
			e.printStackTrace();
			// System.out.println("\nCan't view admin and customer list");
		}
		return role;
	}

	// method for admin to add items in inventory
	public void addItem(String addUpdat, String itemNo, String itemName, String type, String price, String stock) {
		try {

			boolean b = remoteClient.addItem(addUpdat, itemNo, itemName, type, price, stock);
			if (b == true) {
				if (addUpdat != "Add") {
					System.out.println("Item updated in store inventory");
				} else {
					System.out.println("Item added in store inventory");
				}
			} else if (b == false) {
				if (addUpdat != "Add") {
					System.out.println("Item is not in store inventory");
				} else {
					System.out.println("Another item with same number exists in store inventory");
				}
			} else {
				System.out.println("\nCan't add new items");
			}
		} catch (Exception e) {
			e.printStackTrace();
			// System.out.println("\nCan't add new items");
		}
	}

	// method for customer to search items
	public List<String> searchItems() {
		// create array
		List<String> st = new ArrayList<String>();
		try {
			st = remoteClient.searchItems();
		} catch (Exception e) {
			e.printStackTrace();
			// System.out.println("\nCan't view list of items");
		}
		return st;
	}

	// method for admin to remove items from inventory
	public void removeItem(String itemNo) {
		try {
			if (remoteClient.removeItem(itemNo)) {
				System.out.println("Item deleted from inventory");
			} else {
				System.out.println("Item not able to find");
			}
		} catch (Exception e) {
			e.printStackTrace();
			// System.out.println("\nCan't remove item");
		}
	}

	// method for admin to add customer
	public void addCustomer(Boolean flag, String name, String email, String pass) {
		try {

			if (remoteClient.addCustomer(name, email, pass)) {
				System.out.println("\n###Added new Customer successfully");
				if (!flag) {
					// create object of type FrontController and Registration
					FrontController fc = new FrontController();
					Registration reg = new Registration();
					// call display method
					fc.viewLogin(reg.displayLogin());
				}
			} else {
				System.out.println("\n###Please give new email and password");
			}
		} catch (Exception e) {
			e.printStackTrace();
			// System.out.println("\nCan't add new customer");
		}
	}

	// method for customer to add items in shopping cart
	public void addItemsCart(String itemNo, String email, String phone, String cardNo) {
		try {
			remoteClient.addItemsCart(itemNo, email, phone, cardNo);
		} catch (Exception e) {
			System.out.println("\nCan't add item in cart");
		}
	}

	// method for customer to see shopping cart
	public void displayCart(String itemNo, String email, String phone, String cardNo) {
		try {
			remoteClient.displayCart(itemNo, email, phone, cardNo);
		} catch (Exception e) {
			System.out.println("\nCan't display cart items");
		}
	}

	public List<String> displayItems(String userType, String email) {
		// create array to display items
		List<String> ds = new ArrayList<String>();
		try {
			ds = remoteClient.displayItems(userType, email);
		} catch (Exception e) {
			e.printStackTrace();
			// System.out.println("\nCan't display items");
		}
		return ds;
	}

	// method for customer to update items in shopping cart
	public List<String> updateItemIn(String itemNo, String email) {
		// create array to store updated items
		List<String> val = new ArrayList<String>();
		try {
			val = remoteClient.updateItemIn(itemNo, email);
			System.out.println("\n###Item updated in cart successfully");
		} catch (Exception e) {
			e.printStackTrace();
			// System.out.println("\nCan't update item in cart");
		}
		return val;
	}

	// method for customer to remove items in shopping cart
	public void removeItemIn(String itemNo) {
		try {
			if (remoteClient.removeItemIn(itemNo)) {
				System.out.println("Item deleted from shopping cart");
			} else {
				System.out.println("Item is not in store");
			}
		} catch (Exception e) {
			e.printStackTrace();
			// System.out.println("\nCan't remove item from cart");
		}
	}

}// end of class()
